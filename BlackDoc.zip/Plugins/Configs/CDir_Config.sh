cd  ../
cd  RekcahDA_Bot
python  Chat.py
