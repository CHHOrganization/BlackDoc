﻿
Cryptic Hats Hackers organization
BlackDocument Bot

How to use this script; After you 
dowwnload BlackDoc please move it 
out from Telegram folders.
To your phone's files 
(Not Into Your Memorycard) 
and unZip the file then 
use the following commands 
to open it.
Use Termux or Command Prompt

In Android Using Termux:
firstly give your Termux Storage 
Permission at your phone settings, 
In Apps... 

Commands;
pkg install python
cd /sdcard
cd BlackDoc
cd Plugins
cd RekcahDA_Bot
python Chat.py

In Windows Using Command Prompt:
Firstly save your BlackDoc folder in your 
Computer and Install Python in your 
Computer from Google 
Then use this commands to run it.

Commands;
dir
cd Documents
dir
cd BlackDoc
cd Plugins
cd RekcahDA_Bot
python Chat.py

About BlackDoc Bot
BlackDoc Bot is a script of CHH 
Organization for quick Qs&As 
for our Organization Preminum 
members.
This script has security: level 1 
as well, We will always keep it updated 
about new response for more features.

This is BlackDoc V0.0.03
Chating Response Level: 1.01
Security Level 1.02
Features;
How To Hack
How To Register
How To Cpde With Different Languages
How To Configure Yaaic
Commands
Rules

Powered By: CHHOrg
Promoted By: DarkDoor
