apt  update
apt  upgrade
pkg  install python
pkg  install git
cd  Plugins
cd  MyDownloads
git  clone https://github.com/htr-tech/termux-shell.git
